op_version_set = 1
class Conv2d(Module):
  __parameters__ = ["weight", ]
  transposed : bool
  weight : Tensor
  training : bool
  def forward(self: __torch__.torch.nn.modules.conv.___torch_mangle_1.Conv2d,
    input: Tensor) -> Tensor:
    _0 = (self).conv2d_forward(input, self.weight, )
    return _0
  def conv2d_forward(self: __torch__.torch.nn.modules.conv.___torch_mangle_1.Conv2d,
    input: Tensor,
    weight: Tensor) -> Tensor:
    _1 = __torch__.torch.nn.functional.___torch_mangle_28.pad
    _2 = uninitialized(Tensor)
    if torch.eq("zeros", "circular"):
      _5 = torch.floordiv(torch.add(1, 1), 2)
      _6 = torch.floordiv(1, 2)
      _7 = torch.floordiv(torch.add(1, 1), 2)
      _8 = [_5, _6, _7, torch.floordiv(1, 2)]
      _9 = _1(input, _8, "circular", 0., )
      _10 = [0, 0]
      _3, _4 = True, torch.conv2d(_9, weight, None, [1, 1], _10, [1, 1], 1)
    else:
      _3, _4 = False, _2
    if _3:
      _11 = _4
    else:
      _11 = torch.conv2d(input, weight, None, [1, 1], [1, 1], [1, 1], 1)
    return _11
