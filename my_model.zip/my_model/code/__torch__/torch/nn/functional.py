op_version_set = 1
def pad(input: Tensor,
    pad: List[int],
    mode: str="constant",
    value: float=0.) -> Tensor:
  _0 = __torch__.torch.nn.functional._pad_circular
  _1 = __torch__.torch.nn.functional.___torch_mangle_26._pad_circular
  _2 = __torch__.torch.nn.functional.___torch_mangle_27._pad_circular
  _3 = uninitialized(Tensor)
  _4 = torch.eq(torch.remainder(torch.len(pad), 2), 0)
  if _4:
    pass
  else:
    ops.prim.RaiseException("Exception")
  _5 = torch.le(torch.floordiv(torch.len(pad), 2), torch.dim(input))
  if _5:
    pass
  else:
    ops.prim.RaiseException("Exception")
  if torch.eq(mode, "constant"):
    _6 = torch.constant_pad_nd(input, pad, value)
  else:
    if torch.eq(value, 0):
      pass
    else:
      ops.prim.RaiseException("Exception")
    if torch.eq(torch.dim(input), 3):
      if torch.eq(torch.len(pad), 2):
        pass
      else:
        ops.prim.RaiseException("Exception")
      if torch.eq(mode, "reflect"):
        _8 = torch.reflection_pad1d(input, pad)
      else:
        if torch.eq(mode, "replicate"):
          _9 = torch.replication_pad1d(input, pad)
        else:
          if torch.eq(mode, "circular"):
            _10 = _0(input, pad, )
          else:
            ops.prim.RaiseException("Exception")
            _10 = _3
          _9 = _10
        _8 = _9
      _7 = _8
    else:
      if torch.eq(torch.dim(input), 4):
        if torch.eq(torch.len(pad), 4):
          pass
        else:
          ops.prim.RaiseException("Exception")
        if torch.eq(mode, "reflect"):
          _12 = torch.reflection_pad2d(input, pad)
        else:
          if torch.eq(mode, "replicate"):
            _13 = torch.replication_pad2d(input, pad)
          else:
            if torch.eq(mode, "circular"):
              _14 = _1(input, pad, )
            else:
              ops.prim.RaiseException("Exception")
              _14 = _3
            _13 = _14
          _12 = _13
        _11 = _12
      else:
        if torch.eq(torch.dim(input), 5):
          if torch.eq(torch.len(pad), 6):
            pass
          else:
            ops.prim.RaiseException("Exception")
          if torch.eq(mode, "reflect"):
            ops.prim.RaiseException("Exception")
            _16 = _3
          else:
            if torch.eq(mode, "replicate"):
              _17 = torch.replication_pad3d(input, pad)
            else:
              _18 = torch.eq(mode, "circular")
              if _18:
                _19 = _2(input, pad, )
              else:
                ops.prim.RaiseException("Exception")
                _19 = _3
              _17 = _19
            _16 = _17
          _15 = _16
        else:
          ops.prim.RaiseException("Exception")
          _15 = _3
        _11 = _15
      _7 = _11
    _6 = _7
  return _6
def batch_norm(input: Tensor,
    running_mean: Optional[Tensor],
    running_var: Optional[Tensor],
    weight: Optional[Tensor]=None,
    bias: Optional[Tensor]=None,
    training: bool=False,
    momentum: float=0.10000000000000001,
    eps: float=1.0000000000000001e-05) -> Tensor:
  if training:
    size = torch.size(input)
    size_prods = size[0]
    size_prods0 = size_prods
    for i in range(torch.sub(torch.len(size), 2)):
      size_prods0 = torch.mul(size_prods0, size[torch.add(i, 2)])
    if torch.eq(size_prods0, 1):
      ops.prim.RaiseException("Exception")
    else:
      pass
  else:
    pass
  _20 = torch.batch_norm(input, weight, bias, running_mean, running_var, training, momentum, eps, True)
  return _20
def relu(input: Tensor,
    inplace: bool=False) -> Tensor:
  if inplace:
    result = torch.relu_(input)
  else:
    result = torch.relu(input)
  return result
def _max_pool2d(input: Tensor,
    kernel_size: List[int],
    stride: Optional[List[int]]=None,
    padding: List[int],
    dilation: List[int],
    ceil_mode: bool=False,
    return_indices: bool=False) -> Tensor:
  if torch.__is__(stride, None):
    stride0 = annotate(List[int], [])
  else:
    stride0 = unchecked_cast(List[int], stride)
  _21 = torch.max_pool2d(input, kernel_size, stride0, padding, dilation, ceil_mode)
  return _21
def adaptive_avg_pool2d(input: Tensor,
    output_size: List[int]) -> Tensor:
  _output_size = torch.list_with_default(output_size, torch.size(input))
  _22 = torch.adaptive_avg_pool2d(input, _output_size)
  return _22
def linear(input: Tensor,
    weight: Tensor,
    bias: Optional[Tensor]=None) -> Tensor:
  if torch.eq(torch.dim(input), 2):
    _23 = torch.__isnot__(bias, None)
  else:
    _23 = False
  if _23:
    bias0 = unchecked_cast(Tensor, bias)
    ret = torch.addmm(bias0, input, torch.t(weight), beta=1, alpha=1)
  else:
    output = torch.matmul(input, torch.t(weight))
    if torch.__isnot__(bias, None):
      bias1 = unchecked_cast(Tensor, bias)
      output0 = torch.add_(output, bias1, alpha=1)
    else:
      output0 = output
    ret = output0
  return ret
def _pad_circular(input: Tensor,
    padding: List[int]) -> Tensor:
  _24 = torch.slice(input, 0, 0, 9223372036854775807, 1)
  _25 = torch.slice(_24, 1, 0, 9223372036854775807, 1)
  _26 = torch.slice(_25, 2, 0, padding[-1], 1)
  input0 = torch.cat([input, _26], 2)
  _27 = torch.slice(input0, 0, 0, 9223372036854775807, 1)
  _28 = torch.slice(_27, 1, 0, 9223372036854775807, 1)
  _29 = torch.neg(torch.add(padding[-1], padding[-2]))
  _30 = torch.slice(_28, 2, _29, torch.neg(padding[-1]), 1)
  input1 = torch.cat([_30, input0], 2)
  if torch.gt(torch.len(padding), 2):
    _31 = torch.slice(input1, 0, 0, 9223372036854775807, 1)
    _32 = torch.slice(_31, 1, 0, 9223372036854775807, 1)
    _33 = torch.slice(_32, 2, 0, 9223372036854775807, 1)
    _34 = torch.slice(_33, 3, 0, padding[-3], 1)
    input3 = torch.cat([input1, _34], 3)
    _35 = torch.slice(input3, 0, 0, 9223372036854775807, 1)
    _36 = torch.slice(_35, 1, 0, 9223372036854775807, 1)
    _37 = torch.slice(_36, 2, 0, 9223372036854775807, 1)
    _38 = torch.neg(torch.add(padding[-3], padding[-4]))
    _39 = torch.slice(_37, 3, _38, torch.neg(padding[-3]), 1)
    input2 = torch.cat([_39, input3], 3)
  else:
    input2 = input1
  if torch.gt(torch.len(padding), 4):
    _40 = torch.slice(input2, 0, 0, 9223372036854775807, 1)
    _41 = torch.slice(_40, 1, 0, 9223372036854775807, 1)
    _42 = torch.slice(_41, 2, 0, 9223372036854775807, 1)
    _43 = torch.slice(_42, 3, 0, 9223372036854775807, 1)
    _44 = torch.slice(_43, 4, 0, padding[-5], 1)
    input5 = torch.cat([input2, _44], 4)
    _45 = torch.slice(input5, 0, 0, 9223372036854775807, 1)
    _46 = torch.slice(_45, 1, 0, 9223372036854775807, 1)
    _47 = torch.slice(_46, 2, 0, 9223372036854775807, 1)
    _48 = torch.slice(_47, 3, 0, 9223372036854775807, 1)
    _49 = torch.neg(torch.add(padding[-5], padding[-6]))
    _50 = torch.slice(_48, 4, _49, torch.neg(padding[-5]), 1)
    input4 = torch.cat([_50, input5], 4)
  else:
    input4 = input2
  return input4
